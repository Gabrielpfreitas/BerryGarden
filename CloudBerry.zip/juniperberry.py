#__________________________________________________________________________________________________________________________________________#
# MULTIPARAMETER BIOAEROSOL SPECTROMETER PYTHON FUNCTIONS
# author: Gabriel Pereira Freitas
# contact: gabriel.freitas@aces.su.se

import numpy as np
import pandas as pd
import glob2
import tqdm
import matplotlib.pyplot as plt
from time import sleep
from IPython.display import clear_output
from sklearn.cluster import KMeans
import os

def printc(s=None,os_n = 1, skip=False):
        
    if skip == False:
    
        os.write(os_n, (s+'\n').encode())
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
